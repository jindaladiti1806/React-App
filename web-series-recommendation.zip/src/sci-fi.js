const sciFi = [
  {
    id: 1,
    title: "West World",
    summary:
      "Westworld is an exclusive theme park where those who can afford a ticket can live without limits. Partners Arnold Weber and Robert Ford created lifelike robots that pass for humans called hosts. The hosts allow guests to live out their fantasies (without harming humans) in the park.",
    image: "/assets/west.jpg",
    imdb: "8.7/10"
  },
  {
    id: 2,
    title: "Black Mirror",
    summary:
      "An anthology series exploring a twisted, high-tech multiverse where humanity's greatest innovations and darkest instincts collide. ... Black Mirror is a contemporary British anthology series with stories that tap into the collective unease about our modern world.",
    image: "/assets/black.jpg",
    imdb: "8.8/10"
  },
  {
    id: 3,
    title: "Dark",
    summary:
      "Dark is a German drama on Netflix about time travel and confused teenagers. ... I guess I no longer need to describe Dark as grim—central to the plot is the unexplainable disappearance of two young boys in the small town of Winden—but the show's preoccupation is whether or not we're doomed to repeat past mistakes.",
    image: "/assets/dark.jpg",
    imdb: "8.8/10"
  }
];

export default sciFi;
