const crime = [
  {
    id: 1,
    title: "Mind Hunter",
    summary:
      "Plot. Mindhunter revolves around FBI agents Holden Ford (Jonathan Groff) and Bill Tench (Holt McCallany), along with psychologist Wendy Carr (Anna Torv), who operate the FBI's Behavioral Science Unit within the Training Division at the FBI Academy in Quantico, Virginia.",
    image: "/assets/mind-hunter.jpg",
    imdb: "8.6/10"
  },
  {
    id: 2,
    title: "You",
    summary:
      "The first season follows the story of Joe Goldberg, a bookstore manager in New York, who upon meeting Guinevere Beck, an aspiring writer, becomes infatuated with her. He feeds his toxic obsession using social media and other technology to track her presence and remove obstacles to their romance.",
    image: "/assets/you.jpg",
    imdb: "7.8/10"
  },
  {
    id: 3,
    title: "How to Get Away with Murder",
    summary:
      "A group of ambitious law students and their brilliant criminal defense professor become involved in a twisted murder plot that promises to change the course of their lives.",
    image: "/assets/murder.jpg",
    imdb: "8.1/10"
  }
];

export default crime;
