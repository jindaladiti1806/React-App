const comedy = [
  {
    id: 1,
    title: "F.R.I.E.N.D.S",
    summary:
      "Follows the personal and professional lives of six twenty to thirty-something-year-old friends living in Manhattan. Ross Geller, Rachel Green, Monica Geller, Joey Tribbiani, Chandler Bing, and Phoebe Buffay are six 20 something year olds living in New York City.",
    image: "/assets/friends.jpg",
    imdb: "8.9/10"
  },
  {
    id: 1,
    title: "The Big Bang Theory",
    summary:
      'The Big Bang Theory is a comedy about brilliant physicists, Leonard and Sheldon, who are the kind of "beautiful minds" that understand how the universe works. But none of that genius helps them interact with people, especially women. All this begins to change when a free-spirited beauty named Penny moves in next door.',
    image: "/assets/big-bang.jpg",
    imdb: "8.1/10"
  },
  {
    id: 1,
    title: "The Office",
    summary:
      "A mockumentary on a group of typical office workers, where the workday consists of ego clashes, inappropriate behavior, and tedium. A mediocre paper company in the hands of Scranton, PA branch manager Michael Scott. ... Some of these workers are Michael Scott, the boss, who isn't too bright or funny.",
    image: "/assets/office.jpg",
    imdb: "8.9/10"
  }
];

export default comedy;
