import React, { useState } from "react";
import "./styles.css";
//import friend from './assets/friends.jpg';
import comedy from "./comedy";
import crime from "./crime";
import sciFi from "./sci-fi";

export default function App() {
  const [genre, setGenre] = useState([...comedy, ...crime, ...sciFi]);
  const [id, setId] = useState(null);

  const handleSelect = (i) => {
    setId(i);
    if (i === 2) {
      setGenre(comedy);
    } else if (i === 3) {
      setGenre(crime);
    } else if (i === 4) {
      setGenre(sciFi);
    }
  };

  return (
    <div className="App">
      <h2>🎥 Web Series Recommendation</h2>
      <h4>
        {" "}
        Here are some amazing list of Web Series you can watch in your free time
        🍿!
      </h4>

      {/* buttons */}
      <div className="select-button">
        <button
          className={genre.length > 3 ? "btn-all" : null}
          onClick={() => setGenre([...comedy, ...crime])}
        >
          All Genere
        </button>

        {/* button1 */}
        <button
          className={id === 2 ? "btn-all" : null}
          onClick={() => handleSelect(2)}
        >
          Comedy
        </button>

        {/* button2 */}
        <button
          className={id === 3 ? "btn-all" : null}
          onClick={() => handleSelect(3)}
        >
          Crime
        </button>

        {/* button3 */}
        <button
          className={id === 4 ? "btn-all" : null}
          onClick={() => handleSelect(4)}
        >
          Sci fi
        </button>
      </div>
      <div className="divider"></div>
      {genre.map((data, i) => {
        return (
          <div
            className={i % 2 !== 0 ? "recommendation back" : "recommendation"}
            key={i}
          >
            <div className="image-div">
              <img src={data.image} alt="friends" />
            </div>
            <div className="details">
              <h3>{data.title}</h3>
              <p>{data.summary}</p>
              <p>
                imdb : <span>{data.imdb}</span>
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
